import 'bootswatch/dist/cosmo/bootstrap.css';
import '../global.css';
import '../login.css';

import '../public/css/font-awesome-4.7.0/css/font-awesome.min.css';
const MyApp = ({ Component, pageProps }) => {
    return <Component {...pageProps} />
}
export default MyApp