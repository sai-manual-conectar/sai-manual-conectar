import Layout from '../components/Layout'

const Blog = ()=>(
    <Layout footer={false} dark={true}>
        <h1>BLOG</h1>
    </Layout>
)

export default Blog;