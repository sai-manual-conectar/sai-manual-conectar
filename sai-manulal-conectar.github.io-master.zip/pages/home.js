import React, { useState } from 'react';
import Layout from "../components/Layout";
import styles from "../components/CardGrid.module.sass";

const Card = ({ imageSrc, onClick, activity }) => {

  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = React.createRef();

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className={`card ${styles.card_act}`} onClick={onClick}>
      <audio ref={audioRef} src={`audio/activity/icons_description/${activity}.mp3`} />
      <div className="btn" onClick={togglePlay}>
        <img src={imageSrc} alt="Card" />
       <p><strong className="text-center"> {activity.toUpperCase().replace("_"," ")}</strong></p> 
      </div>
    </div>
  );
};

const ActivitiesDescription = () => {
  const activities_list = ["marcar", "ordenar", "escuchar", "pintar","hablar","jugar","repetir","recortar","observar","competencia_intercultural","relacionar"]



return (
  <Layout>
    <header className="row">
      <div className="col-md-8 offset-md-2 d-flex align-items-center">
        <div className="card card-body d-flex align-items-center main-banner">
          <div className="row">
            <h1 className="text-white">¡Bienvenido!</h1>
            <h3 className="text-white">En este portal encontrarás los siguientes tipos de activdades:</h3>

            <div className={`card ${styles.card_grid} ${styles.card_home}`} >
              {activities_list.map((activity, index) => (

                <Card
                  key={index}
                  imageSrc={`images/icons_description/${activity}.png`}
                  activity={activity}
                />

              ))}
            </div>
            <button></button>


          </div>
        </div>
      </div>
    </header>
  </Layout>
);
};

export default ActivitiesDescription;
