"use strict";
self["webpackHotUpdate_N_E"]("pages/home",{

/***/ "./pages/home.js":
/*!***********************!*\
  !*** ./pages/home.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/CardGrid.module.sass */ "./components/CardGrid.module.sass");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\lucas.eichhorn-ext\\Downloads\\sai-manulal-conectar.github.io-master\\pages\\home.js",
    _this = undefined,
    _s = $RefreshSig$();






var Card = function Card(_ref) {
  _s();

  var imageSrc = _ref.imageSrc,
      onClick = _ref.onClick,
      activity = _ref.activity;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
      isPlaying = _useState[0],
      setIsPlaying = _useState[1];

  var audioRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createRef();

  var togglePlay = function togglePlay() {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }

    setIsPlaying(!isPlaying);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "card ".concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_act)),
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("audio", {
      ref: audioRef,
      src: "audio/activity/icons_description/".concat(activity, ".mp3")
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("button", {
      className: "btn",
      onClick: togglePlay,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
        src: imageSrc,
        alt: "Card"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("strong", {
        className: "text-center",
        children: [" ", activity.toUpperCase()]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, _this);
};

_s(Card, "dxr5RgzQJlMZkbQdHY9iHZ+FF0w=");

_c = Card;

var ActivitiesDescription = function ActivitiesDescription() {
  var activities_list = ["marcar", "ordenar", "escuchar", "pintar", "hablar", "jugar", "repetir", "recortar", "observar", "competencia_intercultural", "relacionar"];
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("header", {
      className: "row",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "col-md-8 offset-md-2 d-flex align-items-center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "card card-body d-flex align-items-center main-banner",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h1", {
              className: "text-white",
              children: "Bienvenido!"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h3", {
              className: "text-white",
              children: "En este portal encontrar\xE1s los siguientes tipos de activdades:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: (_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_grid),
              children: activities_list.map(function (activity, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Card, {
                  imageSrc: "images/icons_description/".concat(activity, ".png"),
                  activity: activity
                }, index, false, {
                  fileName: _jsxFileName,
                  lineNumber: 47,
                  columnNumber: 17
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("button", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 36,
    columnNumber: 3
  }, _this);
};

_c2 = ActivitiesDescription;
/* harmony default export */ __webpack_exports__["default"] = (ActivitiesDescription);

var _c, _c2;

$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "ActivitiesDescription");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS42Zjg4ZGFkNzUyMmQ2YmY0ZDg3OS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7OztBQUVBLElBQU1JLElBQUksR0FBRyxTQUFQQSxJQUFPLE9BQXFDO0FBQUE7O0FBQUEsTUFBbENDLFFBQWtDLFFBQWxDQSxRQUFrQztBQUFBLE1BQXhCQyxPQUF3QixRQUF4QkEsT0FBd0I7QUFBQSxNQUFmQyxRQUFlLFFBQWZBLFFBQWU7O0FBRWhELGtCQUFrQ04sK0NBQVEsQ0FBQyxLQUFELENBQTFDO0FBQUEsTUFBT08sU0FBUDtBQUFBLE1BQWtCQyxZQUFsQjs7QUFDQSxNQUFNQyxRQUFRLGdCQUFHVixzREFBQSxFQUFqQjs7QUFFQSxNQUFNWSxVQUFVLEdBQUcsU0FBYkEsVUFBYSxHQUFNO0FBQ3ZCLFFBQUlKLFNBQUosRUFBZTtBQUNiRSxNQUFBQSxRQUFRLENBQUNHLE9BQVQsQ0FBaUJDLEtBQWpCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xKLE1BQUFBLFFBQVEsQ0FBQ0csT0FBVCxDQUFpQkUsSUFBakI7QUFDRDs7QUFDRE4sSUFBQUEsWUFBWSxDQUFDLENBQUNELFNBQUYsQ0FBWjtBQUNELEdBUEQ7O0FBU0Esc0JBQ0U7QUFBSyxhQUFTLGlCQUFVTCxrRkFBVixDQUFkO0FBQTJDLFdBQU8sRUFBRUcsT0FBcEQ7QUFBQSw0QkFDRTtBQUFPLFNBQUcsRUFBRUksUUFBWjtBQUFzQixTQUFHLDZDQUFzQ0gsUUFBdEM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBRUU7QUFBUSxlQUFTLEVBQUMsS0FBbEI7QUFBd0IsYUFBTyxFQUFFSyxVQUFqQztBQUFBLDhCQUNFO0FBQUssV0FBRyxFQUFFUCxRQUFWO0FBQW9CLFdBQUcsRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFFRTtBQUFRLGlCQUFTLEVBQUMsYUFBbEI7QUFBQSx3QkFBa0NFLFFBQVEsQ0FBQ1UsV0FBVCxFQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQVNELENBdkJEOztHQUFNYjs7S0FBQUE7O0FBeUJOLElBQU1jLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0IsR0FBTTtBQUNsQyxNQUFNQyxlQUFlLEdBQUcsQ0FBQyxRQUFELEVBQVcsU0FBWCxFQUFzQixVQUF0QixFQUFrQyxRQUFsQyxFQUEyQyxRQUEzQyxFQUFvRCxPQUFwRCxFQUE0RCxTQUE1RCxFQUFzRSxVQUF0RSxFQUFpRixVQUFqRixFQUE0RiwyQkFBNUYsRUFBd0gsWUFBeEgsQ0FBeEI7QUFJRixzQkFDRSw4REFBQyx1REFBRDtBQUFBLDJCQUNFO0FBQVEsZUFBUyxFQUFDLEtBQWxCO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLGdEQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLHNEQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLEtBQWY7QUFBQSxvQ0FDRTtBQUFJLHVCQUFTLEVBQUMsWUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUksdUJBQVMsRUFBQyxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBSUU7QUFBSyx1QkFBUyxFQUFFaEIsbUZBQWhCO0FBQUEsd0JBQ0dnQixlQUFlLENBQUNFLEdBQWhCLENBQW9CLFVBQUNkLFFBQUQsRUFBV2UsS0FBWDtBQUFBLG9DQUVuQiw4REFBQyxJQUFEO0FBRUUsMEJBQVEscUNBQThCZixRQUE5QixTQUZWO0FBR0UsMEJBQVEsRUFBRUE7QUFIWixtQkFDT2UsS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZtQjtBQUFBLGVBQXBCO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKRixlQWVFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBNkJDLENBbENEOztNQUFNSjtBQW9DTiwrREFBZUEscUJBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaG9tZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSBcIi4uL2NvbXBvbmVudHMvTGF5b3V0XCI7XHJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4uL2NvbXBvbmVudHMvQ2FyZEdyaWQubW9kdWxlLnNhc3NcIjtcclxuXHJcbmNvbnN0IENhcmQgPSAoeyBpbWFnZVNyYywgb25DbGljaywgYWN0aXZpdHkgfSkgPT4ge1xyXG5cclxuICBjb25zdCBbaXNQbGF5aW5nLCBzZXRJc1BsYXlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGF1ZGlvUmVmID0gUmVhY3QuY3JlYXRlUmVmKCk7XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVBsYXkgPSAoKSA9PiB7XHJcbiAgICBpZiAoaXNQbGF5aW5nKSB7XHJcbiAgICAgIGF1ZGlvUmVmLmN1cnJlbnQucGF1c2UoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF1ZGlvUmVmLmN1cnJlbnQucGxheSgpO1xyXG4gICAgfVxyXG4gICAgc2V0SXNQbGF5aW5nKCFpc1BsYXlpbmcpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17YGNhcmQgJHtzdHlsZXMuY2FyZF9hY3R9YH0gb25DbGljaz17b25DbGlja30+XHJcbiAgICAgIDxhdWRpbyByZWY9e2F1ZGlvUmVmfSBzcmM9e2BhdWRpby9hY3Rpdml0eS9pY29uc19kZXNjcmlwdGlvbi8ke2FjdGl2aXR5fS5tcDNgfSAvPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0blwiIG9uQ2xpY2s9e3RvZ2dsZVBsYXl9PlxyXG4gICAgICAgIDxpbWcgc3JjPXtpbWFnZVNyY30gYWx0PVwiQ2FyZFwiIC8+XHJcbiAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPiB7YWN0aXZpdHkudG9VcHBlckNhc2UoKX08L3N0cm9uZz5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgQWN0aXZpdGllc0Rlc2NyaXB0aW9uID0gKCkgPT4ge1xyXG4gIGNvbnN0IGFjdGl2aXRpZXNfbGlzdCA9IFtcIm1hcmNhclwiLCBcIm9yZGVuYXJcIiwgXCJlc2N1Y2hhclwiLCBcInBpbnRhclwiLFwiaGFibGFyXCIsXCJqdWdhclwiLFwicmVwZXRpclwiLFwicmVjb3J0YXJcIixcIm9ic2VydmFyXCIsXCJjb21wZXRlbmNpYV9pbnRlcmN1bHR1cmFsXCIsXCJyZWxhY2lvbmFyXCJdXHJcblxyXG5cclxuXHJcbnJldHVybiAoXHJcbiAgPExheW91dD5cclxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTggb2Zmc2V0LW1kLTIgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjYXJkLWJvZHkgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBtYWluLWJhbm5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj5CaWVudmVuaWRvITwvaDE+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+RW4gZXN0ZSBwb3J0YWwgZW5jb250cmFyw6FzIGxvcyBzaWd1aWVudGVzIHRpcG9zIGRlIGFjdGl2ZGFkZXM6PC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZF9ncmlkfT5cclxuICAgICAgICAgICAgICB7YWN0aXZpdGllc19saXN0Lm1hcCgoYWN0aXZpdHksIGluZGV4KSA9PiAoXHJcblxyXG4gICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgaW1hZ2VTcmM9e2BpbWFnZXMvaWNvbnNfZGVzY3JpcHRpb24vJHthY3Rpdml0eX0ucG5nYH1cclxuICAgICAgICAgICAgICAgICAgYWN0aXZpdHk9e2FjdGl2aXR5fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uPjwvYnV0dG9uPlxyXG5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2hlYWRlcj5cclxuICA8L0xheW91dD5cclxuKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFjdGl2aXRpZXNEZXNjcmlwdGlvbjtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJMYXlvdXQiLCJzdHlsZXMiLCJDYXJkIiwiaW1hZ2VTcmMiLCJvbkNsaWNrIiwiYWN0aXZpdHkiLCJpc1BsYXlpbmciLCJzZXRJc1BsYXlpbmciLCJhdWRpb1JlZiIsImNyZWF0ZVJlZiIsInRvZ2dsZVBsYXkiLCJjdXJyZW50IiwicGF1c2UiLCJwbGF5IiwiY2FyZF9hY3QiLCJ0b1VwcGVyQ2FzZSIsIkFjdGl2aXRpZXNEZXNjcmlwdGlvbiIsImFjdGl2aXRpZXNfbGlzdCIsImNhcmRfZ3JpZCIsIm1hcCIsImluZGV4Il0sInNvdXJjZVJvb3QiOiIifQ==