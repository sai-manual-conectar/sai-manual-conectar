"use strict";
self["webpackHotUpdate_N_E"]("pages/activities_description",{

/***/ "./pages/activities_description.js":
/*!*****************************************!*\
  !*** ./pages/activities_description.js ***!
  \*****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/CardGrid.module.sass */ "./components/CardGrid.module.sass");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\lucas.eichhorn-ext\\Downloads\\sai-manulal-conectar.github.io-master\\pages\\activities_description.js",
    _this = undefined;






var Card = function Card(_ref) {
  var imageSrc = _ref.imageSrc,
      onClick = _ref.onClick,
      activity = _ref.activity;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "card ".concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_act)),
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
      src: imageSrc,
      alt: "Card"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("strong", {
      className: "text-center",
      children: [" ", activity.toUpperCase()]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, _this);
};

_c = Card;

var ActivitiesDescription = function ActivitiesDescription() {
  var activities_list = ["marcar", "ordenar", "escuchar", "pintar"];

  var handleClick = function handleClick(activity) {
    console.log(activity); // Aquí puedes manejar la lógica de autenticación, como enviar los datos al servidor, etc.
    // Luego de manejar la autenticación, puedes redirigir al usuario a otra página
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("header", {
      className: "row",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "col-md-8 offset-md-2 d-flex align-items-center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "card card-body d-flex align-items-center main-banner",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h2", {
              className: "text-white",
              children: "Bienvenido!"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 15
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h3", {
              children: "En este portal encontraras los siguientes tipos de activdades"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 15
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: (_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_grid),
              children: activities_list.map(function (activity, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Card, {
                  imageSrc: "images/icons_description/".concat(activity, ".png"),
                  activity: activity,
                  onClick: function onClick() {
                    return handleClick(activity);
                  }
                }, index, false, {
                  fileName: _jsxFileName,
                  lineNumber: 37,
                  columnNumber: 21
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, _this);
};

_c2 = ActivitiesDescription;
/* harmony default export */ __webpack_exports__["default"] = (ActivitiesDescription);

var _c, _c2;

$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "ActivitiesDescription");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWN0aXZpdGllc19kZXNjcmlwdGlvbi43NjMzZGMwMDRlMzg4OWVmMTE0Yy5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTs7O0FBRUEsSUFBTUcsSUFBSSxHQUFHLFNBQVBBLElBQU8sT0FBcUM7QUFBQSxNQUFsQ0MsUUFBa0MsUUFBbENBLFFBQWtDO0FBQUEsTUFBeEJDLE9BQXdCLFFBQXhCQSxPQUF3QjtBQUFBLE1BQWZDLFFBQWUsUUFBZkEsUUFBZTtBQUNoRCxzQkFDRTtBQUFLLGFBQVMsaUJBQVVKLGtGQUFWLENBQWQ7QUFBMkMsV0FBTyxFQUFFRyxPQUFwRDtBQUFBLDRCQUNFO0FBQUssU0FBRyxFQUFFRCxRQUFWO0FBQW9CLFNBQUcsRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUFFRTtBQUFRLGVBQVMsRUFBQyxhQUFsQjtBQUFBLHNCQUFrQ0UsUUFBUSxDQUFDRSxXQUFULEVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBTUQsQ0FQRDs7S0FBTUw7O0FBU04sSUFBTU0scUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixHQUFNO0FBQ2xDLE1BQU1DLGVBQWUsR0FBRyxDQUFDLFFBQUQsRUFBVyxTQUFYLEVBQXNCLFVBQXRCLEVBQWtDLFFBQWxDLENBQXhCOztBQUdBLE1BQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNMLFFBQUQsRUFBYztBQUNoQ00sSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLFFBQVosRUFEZ0MsQ0FFaEM7QUFFQTtBQUNELEdBTEQ7O0FBT0Esc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSwyQkFDRTtBQUFRLGVBQVMsRUFBQyxLQUFsQjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxnREFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxzREFBZjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxLQUFmO0FBQUEsb0NBQ0U7QUFBSSx1QkFBUyxFQUFDLFlBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUlFO0FBQUssdUJBQVMsRUFBRUosbUZBQWhCO0FBQUEsd0JBQ0dRLGVBQWUsQ0FBQ0ssR0FBaEIsQ0FBb0IsVUFBQ1QsUUFBRCxFQUFXVSxLQUFYO0FBQUEsb0NBRWpCLDhEQUFDLElBQUQ7QUFFRSwwQkFBUSxxQ0FBOEJWLFFBQTlCLFNBRlY7QUFHRSwwQkFBUSxFQUFFQSxRQUhaO0FBSUUseUJBQU8sRUFBRTtBQUFBLDJCQUFNSyxXQUFXLENBQUNMLFFBQUQsQ0FBakI7QUFBQTtBQUpYLG1CQUNPVSxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRmlCO0FBQUEsZUFBcEI7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQTZCRCxDQXhDRDs7TUFBTVA7QUEwQ04sK0RBQWVBLHFCQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2FjdGl2aXRpZXNfZGVzY3JpcHRpb24uanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gXCIuLi9jb21wb25lbnRzL0xheW91dFwiO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9jb21wb25lbnRzL0NhcmRHcmlkLm1vZHVsZS5zYXNzXCI7XHJcblxyXG5jb25zdCBDYXJkID0gKHsgaW1hZ2VTcmMsIG9uQ2xpY2ssIGFjdGl2aXR5IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9e2BjYXJkICR7c3R5bGVzLmNhcmRfYWN0fWB9IG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICA8aW1nIHNyYz17aW1hZ2VTcmN9IGFsdD1cIkNhcmRcIiAvPlxyXG4gICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+IHthY3Rpdml0eS50b1VwcGVyQ2FzZSgpfTwvc3Ryb25nPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IEFjdGl2aXRpZXNEZXNjcmlwdGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBhY3Rpdml0aWVzX2xpc3QgPSBbXCJtYXJjYXJcIiwgXCJvcmRlbmFyXCIsIFwiZXNjdWNoYXJcIiwgXCJwaW50YXJcIl1cclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gKGFjdGl2aXR5KSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhhY3Rpdml0eSlcclxuICAgIC8vIEFxdcOtIHB1ZWRlcyBtYW5lamFyIGxhIGzDs2dpY2EgZGUgYXV0ZW50aWNhY2nDs24sIGNvbW8gZW52aWFyIGxvcyBkYXRvcyBhbCBzZXJ2aWRvciwgZXRjLlxyXG5cclxuICAgIC8vIEx1ZWdvIGRlIG1hbmVqYXIgbGEgYXV0ZW50aWNhY2nDs24sIHB1ZWRlcyByZWRpcmlnaXIgYWwgdXN1YXJpbyBhIG90cmEgcMOhZ2luYVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TGF5b3V0PlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInJvd1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTggb2Zmc2V0LW1kLTIgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNhcmQtYm9keSBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyIG1haW4tYmFubmVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj5CaWVudmVuaWRvITwvaDI+XHJcbiAgICAgICAgICAgICAgPGgzPkVuIGVzdGUgcG9ydGFsIGVuY29udHJhcmFzIGxvcyBzaWd1aWVudGVzIHRpcG9zIGRlIGFjdGl2ZGFkZXM8L2gzPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNhcmRfZ3JpZH0+XHJcbiAgICAgICAgICAgICAgICB7YWN0aXZpdGllc19saXN0Lm1hcCgoYWN0aXZpdHksIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgIGltYWdlU3JjPXtgaW1hZ2VzL2ljb25zX2Rlc2NyaXB0aW9uLyR7YWN0aXZpdHl9LnBuZ2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eT17YWN0aXZpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDbGljayhhY3Rpdml0eSl9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICA8L0xheW91dD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWN0aXZpdGllc0Rlc2NyaXB0aW9uO1xyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJMYXlvdXQiLCJzdHlsZXMiLCJDYXJkIiwiaW1hZ2VTcmMiLCJvbkNsaWNrIiwiYWN0aXZpdHkiLCJjYXJkX2FjdCIsInRvVXBwZXJDYXNlIiwiQWN0aXZpdGllc0Rlc2NyaXB0aW9uIiwiYWN0aXZpdGllc19saXN0IiwiaGFuZGxlQ2xpY2siLCJjb25zb2xlIiwibG9nIiwiY2FyZF9ncmlkIiwibWFwIiwiaW5kZXgiXSwic291cmNlUm9vdCI6IiJ9