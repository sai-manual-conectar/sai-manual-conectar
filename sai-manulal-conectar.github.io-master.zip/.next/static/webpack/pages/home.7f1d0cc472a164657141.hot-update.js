"use strict";
self["webpackHotUpdate_N_E"]("pages/home",{

/***/ "./pages/home.js":
/*!***********************!*\
  !*** ./pages/home.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/CardGrid.module.sass */ "./components/CardGrid.module.sass");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\lucas.eichhorn-ext\\Downloads\\sai-manulal-conectar.github.io-master\\pages\\home.js",
    _this = undefined,
    _s = $RefreshSig$();






var Card = function Card(_ref) {
  _s();

  var imageSrc = _ref.imageSrc,
      onClick = _ref.onClick,
      activity = _ref.activity;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false),
      isPlaying = _useState[0],
      setIsPlaying = _useState[1];

  var audioRef = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default().createRef();

  var togglePlay = function togglePlay() {
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }

    setIsPlaying(!isPlaying);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    className: "card ".concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_act)),
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("audio", {
      ref: audioRef,
      src: "audio/activity/icons_description/".concat(activity, ".mp3")
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      className: "btn",
      onClick: togglePlay,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
        src: imageSrc,
        alt: "Card"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("strong", {
          className: "text-center",
          children: [" ", activity.toUpperCase().replace("_", " ")]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 8
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 5
  }, _this);
};

_s(Card, "dxr5RgzQJlMZkbQdHY9iHZ+FF0w=");

_c = Card;

var ActivitiesDescription = function ActivitiesDescription() {
  var activities_list = ["marcar", "ordenar", "escuchar", "pintar", "hablar", "jugar", "repetir", "recortar", "observar", "competencia_intercultural", "relacionar"];
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("header", {
      className: "row",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "col-md-8 offset-md-2 d-flex align-items-center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "card card-body d-flex align-items-center main-banner",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h1", {
              className: "text-white",
              children: "\xA1Bienvenido!"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h3", {
              className: "text-white",
              children: "En este portal encontrar\xE1s los siguientes tipos de activdades:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
              className: "card ".concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_grid), " ").concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_3___default().card_home)),
              children: activities_list.map(function (activity, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Card, {
                  imageSrc: "images/icons_description/".concat(activity, ".png"),
                  activity: activity
                }, index, false, {
                  fileName: _jsxFileName,
                  lineNumber: 47,
                  columnNumber: 17
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 13
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("button", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 5
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 36,
    columnNumber: 3
  }, _this);
};

_c2 = ActivitiesDescription;
/* harmony default export */ __webpack_exports__["default"] = (ActivitiesDescription);

var _c, _c2;

$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "ActivitiesDescription");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS43ZjFkMGNjNDcyYTE2NDY1NzE0MS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7OztBQUVBLElBQU1JLElBQUksR0FBRyxTQUFQQSxJQUFPLE9BQXFDO0FBQUE7O0FBQUEsTUFBbENDLFFBQWtDLFFBQWxDQSxRQUFrQztBQUFBLE1BQXhCQyxPQUF3QixRQUF4QkEsT0FBd0I7QUFBQSxNQUFmQyxRQUFlLFFBQWZBLFFBQWU7O0FBRWhELGtCQUFrQ04sK0NBQVEsQ0FBQyxLQUFELENBQTFDO0FBQUEsTUFBT08sU0FBUDtBQUFBLE1BQWtCQyxZQUFsQjs7QUFDQSxNQUFNQyxRQUFRLGdCQUFHVixzREFBQSxFQUFqQjs7QUFFQSxNQUFNWSxVQUFVLEdBQUcsU0FBYkEsVUFBYSxHQUFNO0FBQ3ZCLFFBQUlKLFNBQUosRUFBZTtBQUNiRSxNQUFBQSxRQUFRLENBQUNHLE9BQVQsQ0FBaUJDLEtBQWpCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xKLE1BQUFBLFFBQVEsQ0FBQ0csT0FBVCxDQUFpQkUsSUFBakI7QUFDRDs7QUFDRE4sSUFBQUEsWUFBWSxDQUFDLENBQUNELFNBQUYsQ0FBWjtBQUNELEdBUEQ7O0FBU0Esc0JBQ0U7QUFBSyxhQUFTLGlCQUFVTCxrRkFBVixDQUFkO0FBQTJDLFdBQU8sRUFBRUcsT0FBcEQ7QUFBQSw0QkFDRTtBQUFPLFNBQUcsRUFBRUksUUFBWjtBQUFzQixTQUFHLDZDQUFzQ0gsUUFBdEM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBRUU7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFxQixhQUFPLEVBQUVLLFVBQTlCO0FBQUEsOEJBQ0U7QUFBSyxXQUFHLEVBQUVQLFFBQVY7QUFBb0IsV0FBRyxFQUFDO0FBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQUVDO0FBQUEsK0JBQUc7QUFBUSxtQkFBUyxFQUFDLGFBQWxCO0FBQUEsMEJBQWtDRSxRQUFRLENBQUNVLFdBQVQsR0FBdUJDLE9BQXZCLENBQStCLEdBQS9CLEVBQW1DLEdBQW5DLENBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQVNELENBdkJEOztHQUFNZDs7S0FBQUE7O0FBeUJOLElBQU1lLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0IsR0FBTTtBQUNsQyxNQUFNQyxlQUFlLEdBQUcsQ0FBQyxRQUFELEVBQVcsU0FBWCxFQUFzQixVQUF0QixFQUFrQyxRQUFsQyxFQUEyQyxRQUEzQyxFQUFvRCxPQUFwRCxFQUE0RCxTQUE1RCxFQUFzRSxVQUF0RSxFQUFpRixVQUFqRixFQUE0RiwyQkFBNUYsRUFBd0gsWUFBeEgsQ0FBeEI7QUFJRixzQkFDRSw4REFBQyx1REFBRDtBQUFBLDJCQUNFO0FBQVEsZUFBUyxFQUFDLEtBQWxCO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLGdEQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLHNEQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxFQUFDLEtBQWY7QUFBQSxvQ0FDRTtBQUFJLHVCQUFTLEVBQUMsWUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUksdUJBQVMsRUFBQyxZQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBSUU7QUFBSyx1QkFBUyxpQkFBVWpCLG1GQUFWLGNBQThCQSxtRkFBOUIsQ0FBZDtBQUFBLHdCQUNHaUIsZUFBZSxDQUFDRyxHQUFoQixDQUFvQixVQUFDaEIsUUFBRCxFQUFXaUIsS0FBWDtBQUFBLG9DQUVuQiw4REFBQyxJQUFEO0FBRUUsMEJBQVEscUNBQThCakIsUUFBOUIsU0FGVjtBQUdFLDBCQUFRLEVBQUVBO0FBSFosbUJBQ09pQixLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRm1CO0FBQUEsZUFBcEI7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGLGVBZUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUE2QkMsQ0FsQ0Q7O01BQU1MO0FBb0NOLCtEQUFlQSxxQkFBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9ob21lLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IExheW91dCBmcm9tIFwiLi4vY29tcG9uZW50cy9MYXlvdXRcIjtcclxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi4vY29tcG9uZW50cy9DYXJkR3JpZC5tb2R1bGUuc2Fzc1wiO1xyXG5cclxuY29uc3QgQ2FyZCA9ICh7IGltYWdlU3JjLCBvbkNsaWNrLCBhY3Rpdml0eSB9KSA9PiB7XHJcblxyXG4gIGNvbnN0IFtpc1BsYXlpbmcsIHNldElzUGxheWluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgYXVkaW9SZWYgPSBSZWFjdC5jcmVhdGVSZWYoKTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlUGxheSA9ICgpID0+IHtcclxuICAgIGlmIChpc1BsYXlpbmcpIHtcclxuICAgICAgYXVkaW9SZWYuY3VycmVudC5wYXVzZSgpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXVkaW9SZWYuY3VycmVudC5wbGF5KCk7XHJcbiAgICB9XHJcbiAgICBzZXRJc1BsYXlpbmcoIWlzUGxheWluZyk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtgY2FyZCAke3N0eWxlcy5jYXJkX2FjdH1gfSBvbkNsaWNrPXtvbkNsaWNrfT5cclxuICAgICAgPGF1ZGlvIHJlZj17YXVkaW9SZWZ9IHNyYz17YGF1ZGlvL2FjdGl2aXR5L2ljb25zX2Rlc2NyaXB0aW9uLyR7YWN0aXZpdHl9Lm1wM2B9IC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuXCIgb25DbGljaz17dG9nZ2xlUGxheX0+XHJcbiAgICAgICAgPGltZyBzcmM9e2ltYWdlU3JjfSBhbHQ9XCJDYXJkXCIgLz5cclxuICAgICAgIDxwPjxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj4ge2FjdGl2aXR5LnRvVXBwZXJDYXNlKCkucmVwbGFjZShcIl9cIixcIiBcIil9PC9zdHJvbmc+PC9wPiBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgQWN0aXZpdGllc0Rlc2NyaXB0aW9uID0gKCkgPT4ge1xyXG4gIGNvbnN0IGFjdGl2aXRpZXNfbGlzdCA9IFtcIm1hcmNhclwiLCBcIm9yZGVuYXJcIiwgXCJlc2N1Y2hhclwiLCBcInBpbnRhclwiLFwiaGFibGFyXCIsXCJqdWdhclwiLFwicmVwZXRpclwiLFwicmVjb3J0YXJcIixcIm9ic2VydmFyXCIsXCJjb21wZXRlbmNpYV9pbnRlcmN1bHR1cmFsXCIsXCJyZWxhY2lvbmFyXCJdXHJcblxyXG5cclxuXHJcbnJldHVybiAoXHJcbiAgPExheW91dD5cclxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTggb2Zmc2V0LW1kLTIgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjYXJkLWJvZHkgZC1mbGV4IGFsaWduLWl0ZW1zLWNlbnRlciBtYWluLWJhbm5lclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj7CoUJpZW52ZW5pZG8hPC9oMT5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj5FbiBlc3RlIHBvcnRhbCBlbmNvbnRyYXLDoXMgbG9zIHNpZ3VpZW50ZXMgdGlwb3MgZGUgYWN0aXZkYWRlczo8L2gzPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BjYXJkICR7c3R5bGVzLmNhcmRfZ3JpZH0gJHtzdHlsZXMuY2FyZF9ob21lfWB9ID5cclxuICAgICAgICAgICAgICB7YWN0aXZpdGllc19saXN0Lm1hcCgoYWN0aXZpdHksIGluZGV4KSA9PiAoXHJcblxyXG4gICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgaW1hZ2VTcmM9e2BpbWFnZXMvaWNvbnNfZGVzY3JpcHRpb24vJHthY3Rpdml0eX0ucG5nYH1cclxuICAgICAgICAgICAgICAgICAgYWN0aXZpdHk9e2FjdGl2aXR5fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uPjwvYnV0dG9uPlxyXG5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2hlYWRlcj5cclxuICA8L0xheW91dD5cclxuKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFjdGl2aXRpZXNEZXNjcmlwdGlvbjtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJMYXlvdXQiLCJzdHlsZXMiLCJDYXJkIiwiaW1hZ2VTcmMiLCJvbkNsaWNrIiwiYWN0aXZpdHkiLCJpc1BsYXlpbmciLCJzZXRJc1BsYXlpbmciLCJhdWRpb1JlZiIsImNyZWF0ZVJlZiIsInRvZ2dsZVBsYXkiLCJjdXJyZW50IiwicGF1c2UiLCJwbGF5IiwiY2FyZF9hY3QiLCJ0b1VwcGVyQ2FzZSIsInJlcGxhY2UiLCJBY3Rpdml0aWVzRGVzY3JpcHRpb24iLCJhY3Rpdml0aWVzX2xpc3QiLCJjYXJkX2dyaWQiLCJjYXJkX2hvbWUiLCJtYXAiLCJpbmRleCJdLCJzb3VyY2VSb290IjoiIn0=