"use strict";
self["webpackHotUpdate_N_E"]("pages/activities_description",{

/***/ "./pages/activities_description.js":
/*!*****************************************!*\
  !*** ./pages/activities_description.js ***!
  \*****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/Layout */ "./components/Layout.js");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/CardGrid.module.sass */ "./components/CardGrid.module.sass");
/* harmony import */ var _components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_AudioPlayer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/AudioPlayer */ "./components/AudioPlayer.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\lucas.eichhorn-ext\\Downloads\\sai-manulal-conectar.github.io-master\\pages\\activities_description.js",
    _this = undefined;







var Card = function Card(_ref) {
  var imageSrc = _ref.imageSrc,
      onClick = _ref.onClick,
      activity = _ref.activity;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
    className: "card ".concat((_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_4___default().card_act)),
    onClick: onClick,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_components_AudioPlayer__WEBPACK_IMPORTED_MODULE_2__.default, {
      src: activity
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 8
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("img", {
      src: imageSrc,
      alt: "Card"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("strong", {
      className: "text-center",
      children: [" ", activity.toUpperCase()]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, _this);
};

_c = Card;

var ActivitiesDescription = function ActivitiesDescription() {
  var activities_list = ["marcar", "ordenar", "escuchar", "pintar"];

  var handleClick = function handleClick(activity) {
    console.log(activity); // Aquí puedes manejar la lógica de autenticación, como enviar los datos al servidor, etc.
    // Luego de manejar la autenticación, puedes redirigir al usuario a otra página
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_1__.default, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("header", {
      className: "row",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        className: "col-md-8 offset-md-2 d-flex align-items-center",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "card card-body d-flex align-items-center main-banner",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h1", {
              className: "text-white",
              children: "Bienvenido!"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 15
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h3", {
              className: "text-white",
              children: "En este portal encontrar\xE1s los siguientes tipos de activdades:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 37,
              columnNumber: 15
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: (_components_CardGrid_module_sass__WEBPACK_IMPORTED_MODULE_4___default().card_grid),
              children: activities_list.map(function (activity, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Card, {
                  imageSrc: "images/icons_description/".concat(activity, ".png"),
                  activity: activity,
                  onClick: function onClick() {
                    return handleClick(activity);
                  }
                }, index, false, {
                  fileName: _jsxFileName,
                  lineNumber: 42,
                  columnNumber: 21
                }, _this);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 15
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("button", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 51,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 31,
    columnNumber: 5
  }, _this);
};

_c2 = ActivitiesDescription;
/* harmony default export */ __webpack_exports__["default"] = (ActivitiesDescription);

var _c, _c2;

$RefreshReg$(_c, "Card");
$RefreshReg$(_c2, "ActivitiesDescription");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWN0aXZpdGllc19kZXNjcmlwdGlvbi43NGQ3NTM4NGQ3ZjdjOGRjZmQxMC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsSUFBTUksSUFBSSxHQUFHLFNBQVBBLElBQU8sT0FBcUM7QUFBQSxNQUFsQ0MsUUFBa0MsUUFBbENBLFFBQWtDO0FBQUEsTUFBeEJDLE9BQXdCLFFBQXhCQSxPQUF3QjtBQUFBLE1BQWZDLFFBQWUsUUFBZkEsUUFBZTtBQUNoRCxzQkFDRTtBQUFLLGFBQVMsaUJBQVVMLGtGQUFWLENBQWQ7QUFBMkMsV0FBTyxFQUFFSSxPQUFwRDtBQUFBLDRCQUNHLDhEQUFDLDREQUFEO0FBRVEsU0FBRyxFQUFFQztBQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESCxlQUtFO0FBQUssU0FBRyxFQUFFRixRQUFWO0FBQW9CLFNBQUcsRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTEYsZUFNRTtBQUFRLGVBQVMsRUFBQyxhQUFsQjtBQUFBLHNCQUFrQ0UsUUFBUSxDQUFDRSxXQUFULEVBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBVUQsQ0FYRDs7S0FBTUw7O0FBYU4sSUFBTU0scUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QixHQUFNO0FBQ2xDLE1BQU1DLGVBQWUsR0FBRyxDQUFDLFFBQUQsRUFBVyxTQUFYLEVBQXNCLFVBQXRCLEVBQWtDLFFBQWxDLENBQXhCOztBQUdBLE1BQU1DLFdBQVcsR0FBRyxTQUFkQSxXQUFjLENBQUNMLFFBQUQsRUFBYztBQUNoQ00sSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLFFBQVosRUFEZ0MsQ0FFaEM7QUFFQTtBQUNELEdBTEQ7O0FBT0Esc0JBQ0UsOERBQUMsdURBQUQ7QUFBQSwyQkFDRTtBQUFRLGVBQVMsRUFBQyxLQUFsQjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxnREFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxzREFBZjtBQUFBLGlDQUNFO0FBQUsscUJBQVMsRUFBQyxLQUFmO0FBQUEsb0NBQ0U7QUFBSSx1QkFBUyxFQUFDLFlBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFJLHVCQUFTLEVBQUMsWUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUlFO0FBQUssdUJBQVMsRUFBRUwsbUZBQWhCO0FBQUEsd0JBQ0dTLGVBQWUsQ0FBQ0ssR0FBaEIsQ0FBb0IsVUFBQ1QsUUFBRCxFQUFXVSxLQUFYO0FBQUEsb0NBRWpCLDhEQUFDLElBQUQ7QUFFRSwwQkFBUSxxQ0FBOEJWLFFBQTlCLFNBRlY7QUFHRSwwQkFBUSxFQUFFQSxRQUhaO0FBSUUseUJBQU8sRUFBRTtBQUFBLDJCQUFNSyxXQUFXLENBQUNMLFFBQUQsQ0FBakI7QUFBQTtBQUpYLG1CQUNPVSxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRmlCO0FBQUEsZUFBcEI7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGLGVBZ0JFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQThCRCxDQXpDRDs7TUFBTVA7QUEyQ04sK0RBQWVBLHFCQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2FjdGl2aXRpZXNfZGVzY3JpcHRpb24uanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTGF5b3V0IGZyb20gXCIuLi9jb21wb25lbnRzL0xheW91dFwiO1xyXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuLi9jb21wb25lbnRzL0NhcmRHcmlkLm1vZHVsZS5zYXNzXCI7XHJcbmltcG9ydCBBdWRpb1BsYXllciBmcm9tIFwiLi4vY29tcG9uZW50cy9BdWRpb1BsYXllclwiO1xyXG5cclxuY29uc3QgQ2FyZCA9ICh7IGltYWdlU3JjLCBvbkNsaWNrLCBhY3Rpdml0eSB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtgY2FyZCAke3N0eWxlcy5jYXJkX2FjdH1gfSBvbkNsaWNrPXtvbkNsaWNrfT5cclxuICAgICAgIDxBdWRpb1BsYXllciBcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgc3JjPXthY3Rpdml0eX1cclxuICAgICAgICAgICAgIC8+XHJcbiAgICAgIDxpbWcgc3JjPXtpbWFnZVNyY30gYWx0PVwiQ2FyZFwiIC8+XHJcbiAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj4ge2FjdGl2aXR5LnRvVXBwZXJDYXNlKCl9PC9zdHJvbmc+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgQWN0aXZpdGllc0Rlc2NyaXB0aW9uID0gKCkgPT4ge1xyXG4gIGNvbnN0IGFjdGl2aXRpZXNfbGlzdCA9IFtcIm1hcmNhclwiLCBcIm9yZGVuYXJcIiwgXCJlc2N1Y2hhclwiLCBcInBpbnRhclwiXVxyXG5cclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoYWN0aXZpdHkpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKGFjdGl2aXR5KVxyXG4gICAgLy8gQXF1w60gcHVlZGVzIG1hbmVqYXIgbGEgbMOzZ2ljYSBkZSBhdXRlbnRpY2FjacOzbiwgY29tbyBlbnZpYXIgbG9zIGRhdG9zIGFsIHNlcnZpZG9yLCBldGMuXHJcblxyXG4gICAgLy8gTHVlZ28gZGUgbWFuZWphciBsYSBhdXRlbnRpY2FjacOzbiwgcHVlZGVzIHJlZGlyaWdpciBhbCB1c3VhcmlvIGEgb3RyYSBww6FnaW5hXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxMYXlvdXQ+XHJcbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtOCBvZmZzZXQtbWQtMiBkLWZsZXggYWxpZ24taXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY2FyZC1ib2R5IGQtZmxleCBhbGlnbi1pdGVtcy1jZW50ZXIgbWFpbi1iYW5uZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3dcIj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPkJpZW52ZW5pZG8hPC9oMT5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPkVuIGVzdGUgcG9ydGFsIGVuY29udHJhcsOhcyBsb3Mgc2lndWllbnRlcyB0aXBvcyBkZSBhY3RpdmRhZGVzOjwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY2FyZF9ncmlkfT5cclxuICAgICAgICAgICAgICAgIHthY3Rpdml0aWVzX2xpc3QubWFwKChhY3Rpdml0eSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaW1hZ2VTcmM9e2BpbWFnZXMvaWNvbnNfZGVzY3JpcHRpb24vJHthY3Rpdml0eX0ucG5nYH1cclxuICAgICAgICAgICAgICAgICAgICAgIGFjdGl2aXR5PXthY3Rpdml0eX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNsaWNrKGFjdGl2aXR5KX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uPjwvYnV0dG9uPlxyXG5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvaGVhZGVyPlxyXG4gICAgPC9MYXlvdXQ+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFjdGl2aXRpZXNEZXNjcmlwdGlvbjtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiTGF5b3V0Iiwic3R5bGVzIiwiQXVkaW9QbGF5ZXIiLCJDYXJkIiwiaW1hZ2VTcmMiLCJvbkNsaWNrIiwiYWN0aXZpdHkiLCJjYXJkX2FjdCIsInRvVXBwZXJDYXNlIiwiQWN0aXZpdGllc0Rlc2NyaXB0aW9uIiwiYWN0aXZpdGllc19saXN0IiwiaGFuZGxlQ2xpY2siLCJjb25zb2xlIiwibG9nIiwiY2FyZF9ncmlkIiwibWFwIiwiaW5kZXgiXSwic291cmNlUm9vdCI6IiJ9