const Footer = () =>(
<footer className="bg-success main-footer">
    <div className=" text-light text-center">
        <div className="container p-4">
            <h3> CEAR &copy;</h3>
            <p>2024</p>
            <p>All rights reserved.</p>
        </div>
    </div>
</footer>
)
export default Footer;