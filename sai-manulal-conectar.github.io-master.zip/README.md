# sai-manulal-conectar.github.io
export NODE_OPTIONS=--openssl-legacy-provider